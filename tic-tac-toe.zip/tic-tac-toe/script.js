const cells = document.querySelectorAll(".cell");
const status = document.getElementById("status");
const restart = document.getElementById("restart");

const winningLines = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

let board = ["", "", "", "", "", "", "", "", ""];
let player = "X";
let gameOver = false;

function checkWinner() {
  for (const line of winningLines) {
    const a = line[0];
    const b = line[1];
    const c = line[2];
    if (board[a] !== "" && board[a] === board[b] && board[a] === board[c]) {
      return true;
    }
  }
  return false;
}

function handleClick(index) {
  if (board[index] !== "" || gameOver) {
    return;
  }

  board[index] = player;
  cells[index].textContent = player;

  if (checkWinner()) {
    status.textContent = "Player " + player + " wins!";
    gameOver = true;
  } else if (!board.includes("")) {
    status.textContent = "It's a draw!";
    gameOver = true;
  } else {
    player = player === "X" ? "O" : "X";
    status.textContent = "Player " + player + "'s turn";
  }
}

function restartGame() {
  board = ["", "", "", "", "", "", "", "", ""];
  player = "X";
  gameOver = false;
  status.textContent = "Player X's turn";
  cells.forEach(function (cell) {
    cell.textContent = "";
  });
}

cells.forEach(function (cell, index) {
  cell.addEventListener("click", function () {
    handleClick(index);
  });
});

restart.addEventListener("click", restartGame);
